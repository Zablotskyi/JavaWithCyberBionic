public class HelloWithConsole {
    public static void main(String[] args) {
        String name = "Vasyl";
        System.out.println("Hello " + name);
    }
    // in console write:
    // javac HelloWithConsole.java - компіляція файлу
    // java HelloWithConsole - запускаємо файл
}
