public class Hi {
    public static void main(String[] args) {
        System.out.print("Vasyl ");
        System.out.println("Vasyliovych");
    }
}
