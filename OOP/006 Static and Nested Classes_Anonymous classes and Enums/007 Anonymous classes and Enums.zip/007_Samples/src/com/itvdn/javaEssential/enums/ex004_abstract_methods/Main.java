package com.itvdn.javaEssential.enums.ex004_abstract_methods;


/**
 * Типи, що перераховуються (enum).
 */

public class Main {
    public static void main(String[] args) {
        // Об'єкт з посиланням на екземпляр типу Company, що перераховується.
        Company myComp = Company.WEBCAMP;
        System.out.println(myComp);

        // Виклик методів.
        int salary = myComp.getValue();
        String currency = myComp.getCurrency();
        System.out.println("Я заробляю " + salary + " " + currency + " на місяць");
    }
}
