package com.itvdn.javaEssential.ex_003_creation_of_object;

public class Car {

  //Reference type || name of variable || "new" - Instantiation || Constructor
    Car               car               =   new                      Car();
}
