package com.itvdn.javaEssential.ex_008_packages03_lang;

//import java.lang.*;

public class Main {
    public static void main(String[] args) {
        // Пакет java.lang.*; - імпортується JVM за промовчанням.
        // Явно його імпортувати не треба
        String str = new String();
    }
}
