package com.itvdn.javaEssential.ex_006_packages01;

// просто клас

public class Animal {
}
