package com.itvdn.javaEssential.ex_006_packages01;


public class Main {
    public static void main(String[] args) {

        // Якщо два класи лежать в одному пакеті, їх можна використовувати без імпорту

        Animal animal = new Animal();

    }
}
