package com.itvdn.javaEssential.ex_002_access_modifiers;

// access modifiers

public class Car {

    private String model;   // private access modifier
    protected int maxSpeed; // protected access modifier
    int year;               // default access modifier
    public int speed;       // public access modifier

}
