package com.itvdn.javaEssential.ex_009_packages04_without_import;

public class Main {
    public static void main(String[] args) {

        // можна сам імпорт не писати, а вказати повне ім'я класу, який треба використовувати.

        com.itvdn.javaEssential.ex_001_class_declaration.Car myCar =
                new  com.itvdn.javaEssential.ex_001_class_declaration.Car();
    }
}
