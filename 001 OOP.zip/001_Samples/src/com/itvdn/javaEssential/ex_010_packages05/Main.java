package com.itvdn.javaEssential.ex_010_packages05;

public class Main {
    public static void main(String[] args) {

        // використовуємо статичні методи класу Math

        double number = 1;
        double result = Math.cos(Math.PI * number);
    }
}
