package com.itvdn.javaStarter;

public class C01_If {
    public static void main(String[] args) {
        int a = 1, b = 2; // створюємо дві цілочисленні змінні

        // На 9-му рядку створюємо умовну конструкцію if, за умови якої перевіряємо: a менше b

        if (a < b) {     // Якщо умова задовольняє істинність, виконуємо тіло умовної конструкції.
            System.out.println("a < b");     // Гілка 1
        }
    }
}
