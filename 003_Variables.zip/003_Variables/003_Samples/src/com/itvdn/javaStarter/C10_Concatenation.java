package com.itvdn.javaStarter;

public class C10_Concatenation {
    // Зчеплення рядків. (Конкатенація)

    public static void main(String[] args) {
        // 1 варіант.
        String word1 = "Привет ";
        String word2 = "Мир!";
        String phrase = word1 + word2;
        System.out.println(phrase);

        // 2 варіант.
        System.out.println("Hello " + "World!");
    }
}


