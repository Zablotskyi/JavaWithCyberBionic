package com.itvdn.javaStarter;

public class C05_MathSqrt {

    // Math.sqrt() - математична функція, яка отримує квадратний корінь

    public static void main(String[] args) {
        double x = 256;

        double result = Math.sqrt(x);

        System.out.println("Квадратний корінь: " + result);
    }
}
