package com.itvdn.javaStarter;

public class C15_EndlessLoop {
    public static void main(String[] args) {
        // 1.
        while (true) {

        }

        // 2.
        /*
        do {

        }
        while (true);

        // 3.
        for ( ; ; ) {

        }
        */
    }
}
