package com.itvdn.javaProfessional.ex_001_FileInputStream.io_stream;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in, "Cp866"));
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(System.out, "UTF-8"), true);
            // true – означає, що після виклику pw.println(…) можна викликати pw.flush().
            String s = "Привіт світ";
            System.out.println("System.out puts: " + s);
            pw.println("PrintWriter puts: " + s);
            int c = 0;
            pw.println("Посимвольне введення:");
            while ((c = br.read()) != -1)
                pw.println((char) c);
            pw.println("Порядкове введення:");
            do {
                s = br.readLine();
                pw.println(s);
            } while (!s.equals("q"));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

