package com.itvdn.javaProfessional.ex_002_XML.XMLParser;

public class Main {
    public static void main(String[] args) {
        // Зчитуємо файл.xml
        XMLParser xml = new XMLParser("D:/Course/Java Professional Course/007_Serialization_XML_and_JSON/007_Samples/src/com/itvdn/javaProfessional/ex_002_XML/XMLParser/1.xml");
        // Вказуємо шлях, що зчитуватимемо з файлу xml
        String value = xml.get("catalog/book/author");
        System.out.println(value);
    }
}
