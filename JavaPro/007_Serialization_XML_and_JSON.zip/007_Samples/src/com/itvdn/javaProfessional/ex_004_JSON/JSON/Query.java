package com.itvdn.javaProfessional.ex_004_JSON.JSON;

public class Query {
    public int count;
    public String created;
    public String lang;
    public Results results;
}
