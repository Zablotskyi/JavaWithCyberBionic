package com.itvdn.javaStarter;

public class C04_FloatDouble {
    public static void main(String[] args) {
        float variable1 = 0.12345678901234567890f;
        double variable2 = 0.12345678901234567d;

        System.out.println(variable1);
        System.out.println(variable2);
    }
}
