package com.itvdn.javaStarter;

public class C03_DefaultValues {
    public static void main(String[] args) {
        // На 7-му рядку, створюємо змінну з ім'ям a, типу byte та не надаємо їй жодного значення.

        byte a;
        boolean b;
        char c;
        String s;

        // На 14-му рядку - ПОМИЛКА: Забороняється використання неініціалізованої локальної змінної!

        //System.out.println(a);
    }
}
