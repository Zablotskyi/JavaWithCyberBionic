package com.itvdn.javaStarter;

public class C01_Variables {
    public static void main(String[] args) {
        // На 7-му рядку, створюємо змінну з ім'ям a, типу byte та надаємо їй значення 2.

        byte a = 2;

        // На 11-му рядку, друкуємо значення змінної - a, на экран.

        System.out.println(a);
    }
}
