package com.itvdn.javaStarter;

public class C05_Char {
    public static void main(String[] args) {
        char a = 'A';       // Символ
        char b = 0x0041;    // Значення в 16-річному форматі
        char c = '\u265E';  // Значення у форматі unicode

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    }
}
