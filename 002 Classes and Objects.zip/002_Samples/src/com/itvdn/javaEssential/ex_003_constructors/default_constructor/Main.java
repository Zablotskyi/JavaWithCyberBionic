package com.itvdn.javaEssential.ex_003_constructors.default_constructor;

public class Main {
    public static void main(String[] args) {
        // конструктор за замовчуванням створено Java
        Animal animal = new Animal();
    }
}