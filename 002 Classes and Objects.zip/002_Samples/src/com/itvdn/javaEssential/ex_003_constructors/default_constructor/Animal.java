package com.itvdn.javaEssential.ex_003_constructors.default_constructor;

public class Animal {
    private int age;
    // конструктор ми не створювали, тому JVM створить його сама.

    // або можемо створити його руками, як зазначено нижче
    // public Animal() {}
}