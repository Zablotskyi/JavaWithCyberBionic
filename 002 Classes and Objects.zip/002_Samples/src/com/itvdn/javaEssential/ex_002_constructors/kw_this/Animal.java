package com.itvdn.javaEssential.ex_002_constructors.kw_this;

public class Animal {
    private int age;
    private int height;

    // робота ключового слова this
    public Animal(int a, int h) {
        age = a;
        height = h;
    }
}