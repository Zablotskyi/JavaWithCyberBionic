package com.itvdn.javaEssential.ex_005_constructors.private_constructor;

public class Main {
    public static void main(String[] args) {
        // Компілятор нам не дасть можливості створити об'єкт із приватним консруктором
        // Animal animal = new Animal(5);
    }
}