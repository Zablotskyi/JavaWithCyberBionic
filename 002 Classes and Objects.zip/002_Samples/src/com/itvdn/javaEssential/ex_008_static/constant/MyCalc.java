package com.itvdn.javaEssential.ex_008_static.constant;

public class MyCalc {
    // оголошення константи
    private static final float PI_NUMBER = 3.14F;

    {
        // константу змінювати НЕ МОЖНА!
        // PI_NUMBER = 22.1F;
    }
}