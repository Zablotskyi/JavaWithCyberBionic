package com.itvdn.javaEssential.ex_001_constructors.declaration;

public class Animal {
    private int age;

    // оголошення конструктора
    public Animal(int age) {
        this.age = age;
    }
}