package com.itvdn.javaEssential.ex_004_constructors.defaul_not_created;

public class Animal {
    private int age;

    // створили конструктор із параметрами
    // конструктор за замовчуванням створено не буде, доки Ви це не зробите руками
    public Animal(int age) {
        this.age = age;
    }
}