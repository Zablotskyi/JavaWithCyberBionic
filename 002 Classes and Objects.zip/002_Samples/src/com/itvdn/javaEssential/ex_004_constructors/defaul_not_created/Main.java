package com.itvdn.javaEssential.ex_004_constructors.defaul_not_created;

public class Main {
    public static void main(String[] args) {
        // ми оголосили конструтор з параметрами всередині класу Animal, тому конструктор за замовчуванням не був створений.

        // при створенні об'єкта без параметів - компілятор лаятиметься
        // Animal animal = new Animal();
    }
}