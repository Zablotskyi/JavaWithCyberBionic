public class HelloWorld {
    public static void main(String[] args) {

        // На 6-му рядку, друкуємо фразу - Hello World, на экран.

        System.out.println("Hello World!");
    }
}
